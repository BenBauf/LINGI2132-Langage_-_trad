package pass;

public class Comments{
	
	public int testMultiComment(){
		
		int a = 2;
		
		/**
		 * a=5
		 
		
		
		
		int c /*loool*/
		= 4;
		
		/*test*/ int d = 40;
		
		return a;
	}
	
	
}
