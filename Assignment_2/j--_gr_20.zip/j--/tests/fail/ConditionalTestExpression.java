package pass;

import java.lang.System;

public class ConditionalTestExpression{
	
	public int checkIf(int x, int y){
		return (a<b) a:;
	}
	
}
