package pass;

public class Comments{
	
	public int testMultiComment(){
		
		int a = 2;
		
		/*
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 *  This is a multi-mline comment 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 */
		
		return a;
	}
}
