package factorial;

public class MyMath {

	// TODO: implement this function
	public static int factorial(int n) {
		return 0;
	}
}
