package jminusminus;

public abstract class JForInitExpression extends JAST{

	
		
	protected JForInitExpression(int line) {
        super(line);
    }
	
}
