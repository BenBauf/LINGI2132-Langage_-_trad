
package common

import org.scalatest.Matchers
import org.scalatest.FunSuite

abstract class TestSuite extends FunSuite with Matchers