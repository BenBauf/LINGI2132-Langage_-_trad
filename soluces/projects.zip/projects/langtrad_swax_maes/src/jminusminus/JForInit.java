package jminusminus;

public abstract class JForInit extends JAST{

	
		
	protected JForInit(int line) {
        super(line);
    }
	
}
