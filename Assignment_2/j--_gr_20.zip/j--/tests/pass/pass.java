package pass;

public class ConditionalExpression
{
	public int checkIf(int x, int y)
	{
		return (x>y)?x:y;
	}
}
