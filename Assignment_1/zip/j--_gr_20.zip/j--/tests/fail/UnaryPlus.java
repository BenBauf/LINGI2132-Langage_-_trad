package fail;

import java.lang.System;

public class UnaryPlus {
    public static void main(String[] args) {
        System.out.println(+'a');
    }
}
