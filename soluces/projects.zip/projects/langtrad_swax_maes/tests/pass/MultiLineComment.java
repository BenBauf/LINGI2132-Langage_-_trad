package pass;

public class MultiLineComment{
	
	public int multiLineComment(){
		
		int a = 2;
		
		/*
		 * a += 3;
		 * 
		 */
		
		/*scanit*/
		
		/*and_this *****//********//***//*///*/
		
		/*** can you scan that? ***/
		
		/*********************************
		 * 
		 * *****$$*$**$*$*kodkosdosd
		 * 
		 * **********************************\\\\\\\\\\\
		 */
		
		int c /*loool*/
		= 4;
		
		/*test*/ int d = 40;
		
		return a;
	}
}
