package pass;

public class Modulo {
    public int modulo(int x, int y) {
        return x % y;
    }
}
