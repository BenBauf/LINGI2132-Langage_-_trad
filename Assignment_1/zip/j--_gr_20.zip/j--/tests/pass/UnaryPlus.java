package pass;

public class UnaryPlus {
    public int uplus(int x) {
        return +x;
    }
}
