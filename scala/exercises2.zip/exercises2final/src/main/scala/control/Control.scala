package control

object Control {
  
  /*
    
  TODO: 
    
  Create Scala constructs to make this new control block work
   
  loop(1 to 5) { i =>
    
  } onException {
    
  }   
   
   
   This code iterates over a Scala range, 
   i is the current value if iteration passed as argument to the closure.
   If an exception is thrown, it is catched and the the onException block is executed
   before continuing on next value of the range
   
   Hint: Don't hesitate to create intermediate classes
  
  */
  



}